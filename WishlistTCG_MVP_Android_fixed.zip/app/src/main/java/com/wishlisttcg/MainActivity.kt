package com.wishlisttcg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.wishlisttcg.data.AppDatabase
import com.wishlisttcg.data.CardEntity
import kotlinx.coroutines.launch

private val games = listOf("Pokémon TCG", "Magic: The Gathering", "Yu-Gi-Oh!", "One Piece Card Game", "Gundam Card Game", "Riftbound")
private val priorities = listOf("BAJA", "MEDIA", "ALTA")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "wishlist-tcg.db").build()
        setContent { WishlistApp(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WishlistApp(db: AppDatabase) {
    val scope = rememberCoroutineScope()
    val cards by db.cardDao().pendingCards().collectAsState(initial = emptyList())
    var showAdd by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val history by db.cardDao().obtainedCards().collectAsState(initial = emptyList())

    MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Wishlist TCG") },
                    actions = { TextButton(onClick = { showHistory = !showHistory }) { Text(if (showHistory) "Pendientes" else "Historial") } }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "Agregar carta") }
            }
        ) { padding ->
            Column(Modifier.padding(padding).padding(16.dp)) {
                Text(if (showHistory) "Cartas obtenidas" else "Cartas pendientes", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                val list = if (showHistory) history else cards
                if (list.isEmpty()) Text(if (showHistory) "Aún no hay cartas obtenidas." else "Tu Wishlist está vacía. Presiona + para agregar tu primera carta.")
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.id }) { card ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(card.name, style = MaterialTheme.typography.titleMedium)
                                    PriorityTag(card.priority)
                                }
                                Text(card.game, style = MaterialTheme.typography.bodyMedium)
                                if (card.setName.isNotBlank() || card.collectorNumber.isNotBlank())
                                    Text(listOf(card.setName, card.collectorNumber).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                                if (card.notes.isNotBlank()) Text(card.notes, style = MaterialTheme.typography.bodySmall)
                                if (!showHistory) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { scope.launch { db.cardDao().markObtained(card.id, System.currentTimeMillis()) } }) { Text("Marcar obtenida") }
                                        TextButton(onClick = { scope.launch { db.cardDao().delete(card.id) } }) { Text("Eliminar") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showAdd) AddCardDialog(onDismiss = { showAdd = false }, onSave = { card ->
            scope.launch { db.cardDao().insert(card); showAdd = false }
        })
    }
}

@Composable
private fun PriorityTag(priority: String) {
    val color = when (priority) {
        "ALTA" -> MaterialTheme.colorScheme.error
        "MEDIA" -> androidx.compose.ui.graphics.Color(0xFFB7791F)
        else -> androidx.compose.ui.graphics.Color(0xFF238636)
    }
    Surface(color = color.copy(alpha = .14f), shape = MaterialTheme.shapes.small) {
        Text(priority, color = color, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddCardDialog(onDismiss: () -> Unit, onSave: (CardEntity) -> Unit) {
    var name by remember { mutableStateOf("") }
    var game by remember { mutableStateOf(games.first()) }
    var setName by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("MEDIA") }
    var gameExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva carta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre de la carta *") }, singleLine = true)
                ExposedDropdownMenuBox(expanded = gameExpanded, onExpandedChange = { gameExpanded = it }) {
                    OutlinedTextField(game, {}, readOnly = true, label = { Text("Juego") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(gameExpanded) }, modifier = Modifier.menuAnchor())
                    ExposedDropdownMenu(expanded = gameExpanded, onDismissRequest = { gameExpanded = false }) {
                        games.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { game = option; gameExpanded = false }) }
                    }
                }
                OutlinedTextField(setName, { setName = it }, label = { Text("Expansión / colección") }, singleLine = true)
                OutlinedTextField(number, { number = it }, label = { Text("Número de carta") }, singleLine = true)
                OutlinedTextField(language, { language = it }, label = { Text("Idioma") }, singleLine = true)
                Text("Prioridad")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    priorities.forEach { p ->
                        FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p) })
                    }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("Notas (opcional)") })
                Text("Condición objetivo: Mint o superior", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(CardEntity(name=name.trim(), game=game, setName=setName.trim(), collectorNumber=number.trim(), language=language.trim(), priority=priority, notes=notes.trim())) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
