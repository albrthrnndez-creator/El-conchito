package com.wishlisttcg.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val game: String,
    val setName: String = "",
    val collectorNumber: String = "",
    val language: String = "",
    val priority: String,
    val notes: String = "",
    val photoPath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val obtainedAt: Long? = null
)
