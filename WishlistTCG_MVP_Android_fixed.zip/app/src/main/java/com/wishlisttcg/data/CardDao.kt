package com.wishlisttcg.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CardDao {
    @Query("SELECT * FROM cards WHERE obtainedAt IS NULL ORDER BY CASE priority WHEN 'ALTA' THEN 0 WHEN 'MEDIA' THEN 1 ELSE 2 END, game, name")
    fun pendingCards(): Flow<List<CardEntity>>

    @Query("SELECT * FROM cards WHERE obtainedAt IS NOT NULL ORDER BY obtainedAt DESC")
    fun obtainedCards(): Flow<List<CardEntity>>

    @Insert
    suspend fun insert(card: CardEntity): Long

    @Update
    suspend fun update(card: CardEntity)

    @Query("UPDATE cards SET obtainedAt = :date WHERE id = :id")
    suspend fun markObtained(id: Long, date: Long)

    @Query("DELETE FROM cards WHERE id = :id")
    suspend fun delete(id: Long)
}
