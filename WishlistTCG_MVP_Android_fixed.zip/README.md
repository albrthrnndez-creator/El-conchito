# Wishlist TCG (MVP inicial)

Aplicación Android privada, Kotlin + Jetpack Compose + Room.

## Funciones incluidas en esta primera base
- Tema claro/oscuro automático según Android.
- Registro local de cartas.
- Seis juegos iniciales: Pokémon, Magic, Yu-Gi-Oh!, One Piece, Gundam y Riftbound.
- Prioridades baja/media/alta.
- Lista de pendientes.
- Marcar como obtenida y consultar historial.
- Persistencia local con Room (sin internet).

## Requisitos para compilar
- Android Studio (versión reciente)
- JDK 17
- Android SDK Platform 35

## Compilar en GitHub
El workflow `.github/workflows/android.yml` compila con JDK 17 y sube el APK como artefacto (Actions > ejecución > Artifacts).

## Compilar en local
Abrir la carpeta del proyecto en Android Studio, esperar la sincronización de Gradle y elegir:
Build > Build Bundle(s) / APK(s) > Build APK(s).

El APK de depuración se genera normalmente en:
`app/build/outputs/apk/debug/app-debug.apk`

## Pendiente para siguientes iteraciones
- Cámara y guardado de fotografías.
- Reportes PDF/TXT/DOCX.
- Programación de reportes y notificaciones.
- Catálogos externos y precios.
- Reconocimiento de cartas desde fotografía.
